--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dbeducacion;
--
-- Name: dbeducacion; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dbeducacion WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Peru.1252';


ALTER DATABASE dbeducacion OWNER TO postgres;

\connect dbeducacion

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: competencias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.competencias (
    id integer NOT NULL,
    jugador1_id integer,
    jugador2_id integer,
    tiempo_jugador1 interval,
    tiempo_jugador2 interval,
    ganador_id integer
);


ALTER TABLE public.competencias OWNER TO postgres;

--
-- Name: competencias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.competencias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.competencias_id_seq OWNER TO postgres;

--
-- Name: competencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.competencias_id_seq OWNED BY public.competencias.id;


--
-- Name: mensajesprivados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mensajesprivados (
    id integer NOT NULL,
    mensaje text,
    fecha_hora_mensaje timestamp without time zone,
    remitente_id integer,
    destinatario_id integer
);


ALTER TABLE public.mensajesprivados OWNER TO postgres;

--
-- Name: mensajesprivados_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mensajesprivados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mensajesprivados_id_seq OWNER TO postgres;

--
-- Name: mensajesprivados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mensajesprivados_id_seq OWNED BY public.mensajesprivados.id;


--
-- Name: progresousuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.progresousuario (
    id integer NOT NULL,
    niveles_completados integer,
    tiempo_finalizacion timestamp without time zone,
    puntuacion integer,
    usuario_id integer
);


ALTER TABLE public.progresousuario OWNER TO postgres;

--
-- Name: progresousuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.progresousuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.progresousuario_id_seq OWNER TO postgres;

--
-- Name: progresousuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.progresousuario_id_seq OWNED BY public.progresousuario.id;


--
-- Name: puntoscompetencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.puntoscompetencia (
    id integer NOT NULL,
    competencia_id integer,
    ganador_id integer,
    puntos_ganador integer
);


ALTER TABLE public.puntoscompetencia OWNER TO postgres;

--
-- Name: puntoscompetencia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.puntoscompetencia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.puntoscompetencia_id_seq OWNER TO postgres;

--
-- Name: puntoscompetencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.puntoscompetencia_id_seq OWNED BY public.puntoscompetencia.id;


--
-- Name: soporteasistencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.soporteasistencia (
    id integer NOT NULL,
    solicitud text,
    respuesta text,
    fecha_hora_solicitud timestamp without time zone,
    fecha_hora_respuesta timestamp without time zone,
    estado_solicitud character varying(20),
    usuario_id integer
);


ALTER TABLE public.soporteasistencia OWNER TO postgres;

--
-- Name: soporteasistencia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.soporteasistencia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.soporteasistencia_id_seq OWNER TO postgres;

--
-- Name: soporteasistencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.soporteasistencia_id_seq OWNED BY public.soporteasistencia.id;


--
-- Name: tablasclasificacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tablasclasificacion (
    id integer NOT NULL,
    puntuacion integer,
    usuario_id integer
);


ALTER TABLE public.tablasclasificacion OWNER TO postgres;

--
-- Name: tablasclasificacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tablasclasificacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tablasclasificacion_id_seq OWNER TO postgres;

--
-- Name: tablasclasificacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tablasclasificacion_id_seq OWNED BY public.tablasclasificacion.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nombre_usuario character varying(255) NOT NULL,
    edad integer,
    imagen_perfil character varying(255),
    contrasena character varying(8) NOT NULL,
    correo_electronico character varying(255) NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: competencias id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencias ALTER COLUMN id SET DEFAULT nextval('public.competencias_id_seq'::regclass);


--
-- Name: mensajesprivados id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mensajesprivados ALTER COLUMN id SET DEFAULT nextval('public.mensajesprivados_id_seq'::regclass);


--
-- Name: progresousuario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.progresousuario ALTER COLUMN id SET DEFAULT nextval('public.progresousuario_id_seq'::regclass);


--
-- Name: puntoscompetencia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puntoscompetencia ALTER COLUMN id SET DEFAULT nextval('public.puntoscompetencia_id_seq'::regclass);


--
-- Name: soporteasistencia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soporteasistencia ALTER COLUMN id SET DEFAULT nextval('public.soporteasistencia_id_seq'::regclass);


--
-- Name: tablasclasificacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablasclasificacion ALTER COLUMN id SET DEFAULT nextval('public.tablasclasificacion_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: competencias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.competencias (id, jugador1_id, jugador2_id, tiempo_jugador1, tiempo_jugador2, ganador_id) FROM stdin;
\.
COPY public.competencias (id, jugador1_id, jugador2_id, tiempo_jugador1, tiempo_jugador2, ganador_id) FROM '$$PATH$$/3379.dat';

--
-- Data for Name: mensajesprivados; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mensajesprivados (id, mensaje, fecha_hora_mensaje, remitente_id, destinatario_id) FROM stdin;
\.
COPY public.mensajesprivados (id, mensaje, fecha_hora_mensaje, remitente_id, destinatario_id) FROM '$$PATH$$/3375.dat';

--
-- Data for Name: progresousuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.progresousuario (id, niveles_completados, tiempo_finalizacion, puntuacion, usuario_id) FROM stdin;
\.
COPY public.progresousuario (id, niveles_completados, tiempo_finalizacion, puntuacion, usuario_id) FROM '$$PATH$$/3371.dat';

--
-- Data for Name: puntoscompetencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.puntoscompetencia (id, competencia_id, ganador_id, puntos_ganador) FROM stdin;
\.
COPY public.puntoscompetencia (id, competencia_id, ganador_id, puntos_ganador) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: soporteasistencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.soporteasistencia (id, solicitud, respuesta, fecha_hora_solicitud, fecha_hora_respuesta, estado_solicitud, usuario_id) FROM stdin;
\.
COPY public.soporteasistencia (id, solicitud, respuesta, fecha_hora_solicitud, fecha_hora_respuesta, estado_solicitud, usuario_id) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: tablasclasificacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tablasclasificacion (id, puntuacion, usuario_id) FROM stdin;
\.
COPY public.tablasclasificacion (id, puntuacion, usuario_id) FROM '$$PATH$$/3373.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, nombre_usuario, edad, imagen_perfil, contrasena, correo_electronico) FROM stdin;
\.
COPY public.usuarios (id, nombre_usuario, edad, imagen_perfil, contrasena, correo_electronico) FROM '$$PATH$$/3369.dat';

--
-- Name: competencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.competencias_id_seq', 1, false);


--
-- Name: mensajesprivados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mensajesprivados_id_seq', 1, false);


--
-- Name: progresousuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.progresousuario_id_seq', 1, false);


--
-- Name: puntoscompetencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.puntoscompetencia_id_seq', 1, false);


--
-- Name: soporteasistencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.soporteasistencia_id_seq', 1, false);


--
-- Name: tablasclasificacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tablasclasificacion_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, false);


--
-- Name: competencias competencias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencias
    ADD CONSTRAINT competencias_pkey PRIMARY KEY (id);


--
-- Name: mensajesprivados mensajesprivados_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mensajesprivados
    ADD CONSTRAINT mensajesprivados_pkey PRIMARY KEY (id);


--
-- Name: progresousuario progresousuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.progresousuario
    ADD CONSTRAINT progresousuario_pkey PRIMARY KEY (id);


--
-- Name: puntoscompetencia puntoscompetencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puntoscompetencia
    ADD CONSTRAINT puntoscompetencia_pkey PRIMARY KEY (id);


--
-- Name: soporteasistencia soporteasistencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soporteasistencia
    ADD CONSTRAINT soporteasistencia_pkey PRIMARY KEY (id);


--
-- Name: tablasclasificacion tablasclasificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablasclasificacion
    ADD CONSTRAINT tablasclasificacion_pkey PRIMARY KEY (id);


--
-- Name: tablasclasificacion tablasclasificacion_usuario_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablasclasificacion
    ADD CONSTRAINT tablasclasificacion_usuario_id_key UNIQUE (usuario_id);


--
-- Name: usuarios usuarios_correo_electronico_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_correo_electronico_key UNIQUE (correo_electronico);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: competencias competencias_ganador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencias
    ADD CONSTRAINT competencias_ganador_id_fkey FOREIGN KEY (ganador_id) REFERENCES public.usuarios(id);


--
-- Name: competencias competencias_jugador1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencias
    ADD CONSTRAINT competencias_jugador1_id_fkey FOREIGN KEY (jugador1_id) REFERENCES public.usuarios(id);


--
-- Name: competencias competencias_jugador2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.competencias
    ADD CONSTRAINT competencias_jugador2_id_fkey FOREIGN KEY (jugador2_id) REFERENCES public.usuarios(id);


--
-- Name: mensajesprivados mensajesprivados_destinatario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mensajesprivados
    ADD CONSTRAINT mensajesprivados_destinatario_id_fkey FOREIGN KEY (destinatario_id) REFERENCES public.usuarios(id);


--
-- Name: mensajesprivados mensajesprivados_remitente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mensajesprivados
    ADD CONSTRAINT mensajesprivados_remitente_id_fkey FOREIGN KEY (remitente_id) REFERENCES public.usuarios(id);


--
-- Name: progresousuario progresousuario_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.progresousuario
    ADD CONSTRAINT progresousuario_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: puntoscompetencia puntoscompetencia_competencia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puntoscompetencia
    ADD CONSTRAINT puntoscompetencia_competencia_id_fkey FOREIGN KEY (competencia_id) REFERENCES public.competencias(id);


--
-- Name: puntoscompetencia puntoscompetencia_ganador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puntoscompetencia
    ADD CONSTRAINT puntoscompetencia_ganador_id_fkey FOREIGN KEY (ganador_id) REFERENCES public.usuarios(id);


--
-- Name: soporteasistencia soporteasistencia_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soporteasistencia
    ADD CONSTRAINT soporteasistencia_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: tablasclasificacion tablasclasificacion_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablasclasificacion
    ADD CONSTRAINT tablasclasificacion_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- PostgreSQL database dump complete
--

